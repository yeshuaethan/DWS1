//Quote database

quotes = [
	{quote:"A lot of people give up just before they're about to make it. You know you never know when that next obstacle is going to be the last one"},
	{quote:"If it doesn’t kill you it will only make you stronger!"},
	{quote:"Running, its cheeper than therapy!"},
	{quote:"Pain is weakness leaving the body!"},
	{quote:"Whether you think you can or whether you think you can’t, you’re right!"},
	{quote:"Pain is temporary. Quitting lasts forever!"},
	{quote:"Life begins at the end of your comfort zone!"},
	{quote:"The finish line is the beginning of a whole new race!"},
	{quote:"Dreams don’t work unless you do!"},
	{quote:"Fear is what stops you… courages is what keeps you going!"},
	{quote:"If you don’t make mistakes, you aren’t really trying!"},
	{quote:"The body does not want you to do this. As you run, it tells you to stop but the mind must be strong. You always go to far for your body. You must handle the pain with strategy…It is not age; it is not diet. It is the will to succeed!"},
	{quote:"If you always put limits on everything you do, physical or anything else. It will spread into your work and into your life. There are no limits. There are only plateaus, and you must not stay there, you must go beyond them!"},
	{quote:"The hardest thing about exercise is to start doing it. Once you are doing exercise regularly, the hardest thing is to stop it!"},
	{quote:"Success consists of going from failure to failure without loss of enthusiasm!"},
]